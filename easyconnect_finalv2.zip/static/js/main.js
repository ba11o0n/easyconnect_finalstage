console.log("Wrsitband networking frontend initialized."); //Testing 

import '../css/style.css';  
import AOS from 'aos';
import 'aos/dist/aos.css';

AOS.init();
