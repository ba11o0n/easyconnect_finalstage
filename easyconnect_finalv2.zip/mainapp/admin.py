from django.contrib import admin
from .models import Ticket, Device

# Register your models here
admin.site.register(Ticket)
admin.site.register(Device)
